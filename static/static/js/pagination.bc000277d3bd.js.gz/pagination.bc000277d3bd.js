// function Pagination() {

//$('#result').paginathing({

  // Limites your pagination number
  // false or number
//  limitPagination: false,

  // Pagination controls
//  perPage: 5,
//  prevNext: true,
//  firstLast: true,
//  prevText: '&laquo;',
//  nextText: '&raquo;',
//  firstText: 'First',
//  lastText: 'Last',
//  containerClass: 'pagination-container',
  //ulClass: 'pagination',
//  liClass: 'page',
//  activeClass: 'active',
//  disabledClass: 'disabled',
//  limitPagination: 9,
//  containerClass: 'panel-footer mt-4',
//  pageNumbers: true,
//   ulClass: 'pagination flex-wrap justify-content-center',
//})

//}
